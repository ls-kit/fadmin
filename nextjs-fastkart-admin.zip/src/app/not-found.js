import NotFoundPage from "@/Components/404";

export default function NotFound() {
  return <NotFoundPage />;
}
