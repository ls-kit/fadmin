'use client'

import VendorDetails from "@/Components/WithdrawRequest/VendorDetails"

const WithdrawRequest = () => {
    return <VendorDetails />
}

export default WithdrawRequest