"use client";
import AppSettingsForm from "@/Components/AppSettings";

const AppSetting = () => {
  return <AppSettingsForm title={"app_settings"} />;
};

export default AppSetting;
