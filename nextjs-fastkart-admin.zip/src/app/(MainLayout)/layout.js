import Layout from "@/Layout";

export default function RootLayout({ children }) {
  return (
    <Layout >{children}</Layout>
  )
}
