"use client"
import DynamicReports from "@/Components/Reports/DynamicReports";
import React from "react";

const Reports = () => {
  return <DynamicReports />;
};
export default Reports;
