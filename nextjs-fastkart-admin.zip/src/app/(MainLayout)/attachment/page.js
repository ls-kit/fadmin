'use client'
import AttachmentContain from "@/Components/Attachment";

const Media = () => {
    return <AttachmentContain isattachment={true} />;
};
export default Media;